package com.example.assignment;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.assignment.Model.User;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends AppCompatActivity {

    RecyclerView myrecyclerView;
    RecyclerViewAdapter myAdapter;

    List<Recipes> recipes1 = new ArrayList<Recipes>();

    CircleImageView profile_image;
    TextView username;

    FirebaseUser firebaseUser;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ArrayList<Recipes> list = new ArrayList <Recipes>();
         recipes1.add(new Recipes("Bubble Tea","Tea\n" +
                "Milk\n" +
                "Sweetner\n" +
                "Ice\n" +
                "Tapioca Pearls",

                 "Methods", "1. Prepare the tea: Steep the tea bags" +
                 "or leaves with 4 cups of freshly boiled water. Let the tea sit in water until it " +
                 "cools completely. (See note 2)\n\n" +

                 "2. Prepare the simple syrup (if using): Add the water and sugar to a saucepan and" +
                 " quickly stir everything together. Heat the water on medium-high and cook until the" +
                 " water boils and the sugar completely dissolves. Remove the saucepan from heat and" +
                 " let the simple syrup cool before transferring to a jar." +
                 "Cook the tapioca pearls: Bring about 4 cups of water to boil and add the tapioca pearls." +
                 "Stir the pearls and wait for them to float to the top. Then, cook them for another 5 " +
                 "minutes. Test a pearl to see if it has reached the desired level of softness.\n\n" +

                 "3.Cook the" +
                 " pearls for another few minutes if they are still stiff. Use a slotted spoon to remove" +
                 " the pearls from the hot water. Quickly rinse the pearls with water. Transfer the pearls" +
                 " into a bowl, and mix the pearls with a few tablespoons of simple syrup (to taste).\n\n" +

                 "4. Assemble the drinks: Strain the tea into a pitcher. Divide the cooked tapioca pearls into" +
                 " 4 large glasses. Next, add a few ice cubes to each glass. Pour 1 cup of the tea into each" +
                 " glass. Add 1 1/2 tablespoons of milk and 1 1/2 tablespoons of simple syrup into each glass." +
                 " Stir and taste the milk tea. Add more milk or simple syrup to your taste.\n\n" +

                 "5. If you are serving the beverage to guests, have a small pitcher of milk and the jar of " +
                 "simple syrup ready so that each guest can adjust their drinks to their taste. The drink" +
                 " is usually served with large boba straws (large enough for the tapioca pearls to go" +
                 " through). If you don't have the straws on hand, you can use spoons to scoop out the" +
                 " tapioca pearls.",
                R.drawable.bubble));


        recipes1.add(new Recipes("Testing2","testing2\n"
               ,"Method", "Testing2\n",
                R.drawable.beef));

        recipes1.add(new Recipes("Testing3","testing3\n"
                ,"Method", "Testing3\n",
                R.drawable.lamb));

        recipes1.add(new Recipes("Testing4","testing4\n"
                ,"Method", "Testing4\n",
                R.drawable.pork));

        recipes1.add(new Recipes("Testing5","testing5\n"
                ,"Method", "Testing5\n",
                R.drawable.fish));


        myrecyclerView = (RecyclerView)findViewById(R.id.recyclerView_id);

        myAdapter = new RecyclerViewAdapter(this,recipes1);

        myrecyclerView.setLayoutManager(new GridLayoutManager(this,1));

        myrecyclerView.setAdapter(myAdapter);




        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");


    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){

            case R.id.logout:
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(MainActivity.this, StartActivity.class));
                finish();
                return true;


        }
        return false;
    }


}